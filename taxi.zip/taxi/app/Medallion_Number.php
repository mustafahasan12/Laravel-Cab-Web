<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Medallion_Number extends Model
{
      public $table = 'medallion_numbers';
      public $primarykey = 'id';
}
