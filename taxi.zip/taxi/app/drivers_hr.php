<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class drivers_hr extends Model
{
    //
}
