-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 09, 2021 at 06:08 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cab`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2019_08_19_000000_create_failed_jobs_table', 1),
(3, '2021_01_26_092707_create_texi_manifest_table', 2),
(4, '2021_02_09_073729_create_rates_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `rates`
--

DROP TABLE IF EXISTS `rates`;
CREATE TABLE IF NOT EXISTS `rates` (
  `rate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `miles` double(8,2) NOT NULL,
  `a_rates` double(8,2) NOT NULL,
  `wc_rates` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`rate_id`)
);

--
-- Dumping data for table `rates`
--

INSERT INTO `rates` (`rate_id`, `miles`, `a_rates`, `wc_rates`, `created_at`, `updated_at`) VALUES
(1, 0.00, 12.00, 23.79, NULL, NULL),
(2, 1.10, 13.89, 26.53, NULL, NULL),
(3, 1.60, 15.43, 27.73, NULL, NULL),
(4, 2.10, 17.82, 31.51, NULL, NULL),
(5, 2.60, 19.04, 32.38, NULL, NULL),
(6, 3.10, 20.45, 36.08, NULL, NULL),
(7, 3.60, 21.46, 36.74, NULL, NULL),
(8, 4.10, 23.21, 41.29, NULL, NULL),
(9, 4.60, 24.96, 41.96, NULL, NULL),
(10, 5.10, 28.58, 45.72, NULL, NULL),
(11, 5.60, 29.22, 46.21, NULL, NULL),
(12, 6.10, 31.79, 50.37, NULL, NULL),
(13, 6.60, 32.64, 50.88, NULL, NULL),
(14, 7.10, 35.54, 54.74, NULL, NULL),
(15, 7.60, 36.40, 55.40, NULL, NULL),
(16, 8.10, 39.29, 59.63, NULL, NULL),
(17, 8.60, 39.84, 60.12, NULL, NULL),
(18, 9.10, 43.04, 63.28, NULL, NULL),
(19, 9.60, 43.44, 64.00, NULL, NULL),
(20, 10.10, 43.69, 65.52, NULL, NULL),
(21, 10.60, 45.62, 67.72, NULL, NULL),
(22, 11.10, 47.03, 69.92, NULL, NULL),
(23, 11.60, 49.03, 72.12, NULL, NULL),
(24, 12.10, 50.47, 74.32, NULL, NULL),
(25, 12.60, 52.32, 76.52, NULL, NULL),
(26, 13.10, 54.71, 78.72, NULL, NULL),
(27, 13.60, 56.46, 79.53, NULL, NULL),
(28, 14.10, 57.92, 80.97, NULL, NULL),
(29, 14.60, 59.81, 82.35, NULL, NULL),
(30, 15.10, 60.94, 83.68, NULL, NULL),
(31, 15.60, 62.67, 85.76, NULL, NULL),
(32, 16.10, 63.99, 87.83, NULL, NULL),
(33, 16.60, 65.95, 89.91, NULL, NULL),
(34, 17.10, 68.36, 91.98, NULL, NULL),
(35, 17.60, 70.00, 94.06, NULL, NULL),
(36, 18.10, 70.10, 95.21, NULL, NULL),
(37, 18.60, 70.37, 97.26, NULL, NULL),
(38, 19.10, 73.77, 99.31, NULL, NULL),
(39, 19.60, 75.47, 100.37, NULL, NULL),
(40, 20.10, 76.16, 101.38, NULL, NULL),
(41, 20.60, 77.21, 103.14, NULL, NULL),
(42, 21.10, 78.44, 104.31, NULL, NULL),
(43, 21.60, 80.09, 106.29, NULL, NULL),
(44, 22.10, 81.74, 108.26, NULL, NULL),
(45, 22.60, 83.39, 110.24, NULL, NULL),
(46, 23.10, 85.04, 112.21, NULL, NULL),
(47, 23.60, 86.69, 114.19, NULL, NULL),
(48, 24.10, 88.34, 114.95, NULL, NULL),
(49, 24.60, 89.99, 116.90, NULL, NULL),
(50, 25.10, 90.37, 118.85, NULL, NULL),
(51, 25.60, 92.00, 120.80, NULL, NULL),
(52, 26.10, 93.62, 122.75, NULL, NULL),
(53, 26.60, 95.25, 124.70, NULL, NULL),
(54, 27.10, 96.87, 126.65, NULL, NULL),
(55, 27.60, 98.50, 128.60, NULL, NULL),
(56, 28.10, 100.12, 130.55, NULL, NULL),
(57, 28.60, 101.75, 132.50, NULL, NULL),
(58, 29.10, 103.37, 134.45, NULL, NULL),
(59, 29.60, 105.00, 136.40, NULL, NULL),
(60, 30.10, 106.32, 139.83, NULL, NULL),
(61, 30.60, 107.94, 142.12, NULL, NULL),
(62, 31.10, 109.56, 143.87, NULL, NULL),
(63, 31.60, 110.86, 144.20, NULL, NULL),
(64, 32.10, 112.47, 146.15, NULL, NULL),
(65, 32.60, 114.09, 148.10, NULL, NULL),
(66, 33.10, 115.37, 150.05, NULL, NULL),
(67, 33.60, 116.98, 152.00, NULL, NULL),
(68, 34.10, 118.59, 152.23, NULL, NULL),
(69, 34.60, 119.85, 154.15, NULL, NULL),
(70, 35.10, 121.46, 156.08, NULL, NULL),
(71, 35.60, 123.06, 158.00, NULL, NULL),
(72, 36.10, 124.30, 159.20, NULL, NULL),
(73, 36.60, 125.90, 161.12, NULL, NULL),
(74, 37.10, 127.50, 163.03, NULL, NULL),
(75, 37.60, 128.54, 164.95, NULL, NULL),
(76, 38.10, 129.55, 165.71, NULL, NULL),
(77, 38.60, 130.36, 167.61, NULL, NULL),
(78, 39.10, 131.15, 169.51, NULL, NULL),
(79, 39.60, 132.32, 171.41, NULL, NULL),
(80, 40.10, 133.07, 173.31, NULL, NULL),
(81, 40.60, 133.80, 175.21, NULL, NULL),
(82, 41.10, 134.52, 177.11, NULL, NULL),
(83, 41.60, 135.63, 179.01, NULL, NULL),
(84, 42.10, 136.73, 180.91, NULL, NULL),
(85, 42.60, 137.82, 182.81, NULL, NULL),
(86, 43.10, 138.90, 184.71, NULL, NULL),
(87, 43.60, 139.54, 186.61, NULL, NULL),
(88, 44.10, 140.00, 187.00, NULL, NULL),
(93, 5.01, 12.00, 12.10, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `texi_manifest`
--

DROP TABLE IF EXISTS `texi_manifest`;
CREATE TABLE IF NOT EXISTS `texi_manifest` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Date_Of_Service` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Run_Number` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Booking_ID` int(11) NOT NULL,
  `Client_Name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Space_On` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Origin_Street` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Origin_Comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Orig_Apt` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Origin_City` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Origin_Phone` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Origin_Lon` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Origin_Lat` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Space_Off` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Dest_Street` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Dest_Comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Dest_Apt` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Dest_City` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Dest_Phone` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Dest_Lon` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Dest_Lat` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule_time` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Neg_Time` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Appt_Time` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Origin_Actual_Arrive` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Origin_Actual_Depart` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Dest_Actual_Arrive` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Dest_Actual_Depart` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Trip_Distance` double DEFAULT NULL,
  `Fare` double DEFAULT NULL,
  `Fare_Collected` double DEFAULT NULL,
  `Provider_Cost` double DEFAULT NULL,
  `Adjusted_Cost` double DEFAULT NULL,
  `Comments` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `distance_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=356 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `texi_manifest`
--

INSERT INTO `texi_manifest` (`id`, `Date_Of_Service`, `Run_Number`, `Booking_ID`, `Client_Name`, `Space_On`, `Origin_Street`, `Origin_Comment`, `Orig_Apt`, `Origin_City`, `Origin_Phone`, `Origin_Lon`, `Origin_Lat`, `Space_Off`, `Dest_Street`, `Dest_Comment`, `Dest_Apt`, `Dest_City`, `Dest_Phone`, `Dest_Lon`, `Dest_Lat`, `schedule_time`, `Neg_Time`, `Appt_Time`, `Origin_Actual_Arrive`, `Origin_Actual_Depart`, `Dest_Actual_Arrive`, `Dest_Actual_Depart`, `Trip_Distance`, `Fare`, `Fare_Collected`, `Provider_Cost`, `Adjusted_Cost`, `Comments`, `created_at`, `updated_at`, `distance_data`) VALUES
(313, '03/05/2020', 'RUN: BRCITY13T', 69129724, 'LEE, KEVIN', 'AM1', '3030 W 21ST PL', 'MK LBBY CNT', NULL, 'CHICAGO', '773-213-5617', '-87.701160', '41.852739', 'AM1', '10825 S PRAIRIE AVE', NULL, NULL, 'CHICAGO', NULL, '-87.617186', '41.697697', '14:05:00', '14:05', NULL, NULL, NULL, NULL, NULL, 15.1, 3.25, NULL, 76.76, NULL, 'TAXI OK', '2021-02-08 11:00:46', '2021-02-08 11:00:46', '{\"distance\":26940,\"distanceText\":\"26.9 km\",\"duration\":1786,\"durationText\":\"30 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(338, '03/05/2020', 'RUN: BRCITY19T', 69123506, 'SIMMONS, GERALDINE', 'AM1', '514 JEFFERY AVE', '708*307*2715 CELL /', NULL, 'CALUMET CITY', '708-832-2336', '-87.573568', '41.621642', 'AM1', '5758 S MARYLAND AVE', 'PU IN FRONT OF BLDG', NULL, 'CHICAGO', '708-307-2715', '-87.605014', '41.790250', '7:42:00', '7:42', '9:30', NULL, NULL, NULL, NULL, 13.39, 3.25, NULL, 68.98, NULL, 'TAXI OK', '2021-02-08 11:00:57', '2021-02-08 11:00:57', '{\"distance\":24794,\"distanceText\":\"24.8 km\",\"duration\":1262,\"durationText\":\"21 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(339, '03/05/2020', 'RUN: BRCITY19T', 69128305, 'FIELDS, PANCHICO', 'AM1', '7854 S SOUTH SHORE DR', 'RNG BELL 22 1 WY TP', '#304', 'CHICAGO', '773-734-4778', '-87.549369', '41.753216', 'AM1', '121 N LA SALLE ST', 'RNG BELL 22 1 WY TP', NULL, 'CHICAGO', NULL, '-87.632436', '41.883852', '8:12:00', '8:12', '10:00', NULL, NULL, NULL, NULL, 13.36, 3.25, NULL, 68.98, NULL, 'TAXI OK RNG BELL 22 1 WY TP', '2021-02-08 11:00:58', '2021-02-08 11:00:58', '{\"distance\":18244,\"distanceText\":\"18.2 km\",\"duration\":1390,\"durationText\":\"23 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(340, '03/05/2020', 'RUN: BRCITY19T', 69128844, 'LITTLE, JUANITA', 'AM2', '539 N DEARBORN ST', 'MKLBBY  CONTACT', NULL, 'CHICAGO', NULL, '-87.629629', '41.891815', 'AM2', '9355 S VERNON AVE', 'RB', '#1', 'CHICAGO', '773-660-1514', '-87.613023', '41.724350', '9:30:00', '9:30', NULL, NULL, NULL, NULL, NULL, 12.55, 6.5, NULL, 65.64, NULL, 'TAXI OK', '2021-02-08 11:00:58', '2021-02-08 11:00:58', '{\"distance\":23415,\"distanceText\":\"23.4 km\",\"duration\":1352,\"durationText\":\"23 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(341, '03/05/2020', 'RUN: BRCITY19T', 69129672, 'NIXON, BESSIE', 'AM1', '9101 S HALSTED ST', NULL, NULL, 'CHICAGO', '773-483-9123', '-87.643361', '41.728766', 'AM1', '8710 S HARLEM AVE', NULL, NULL, 'BRIDGEVIEW', NULL, '-87.799202', '41.733357', '10:09:00', '10:09', '10:58', NULL, NULL, NULL, NULL, 8.29, 3.25, NULL, 48.95, NULL, 'TAXI OK', '2021-02-08 11:00:58', '2021-02-08 11:00:58', '{\"distance\":13763,\"distanceText\":\"13.8 km\",\"duration\":1422,\"durationText\":\"24 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(342, '03/05/2020', 'RUN: BRCITY19T', 69129777, 'SMITH, LESTER', 'AM1', '3231 EUCLID AVE', 'MK CONTACT', NULL, 'BERWYN', NULL, '-87.791563', '41.833029', 'AM1', '9409 S HARVARD AVE', 'MK CONTACT', '#99', 'CHICAGO', '312-806-2349', '-87.632088', '41.723257', '10:33:00', '10:33', NULL, NULL, NULL, NULL, NULL, 15.81, 3.25, NULL, 80.1, NULL, 'TAXI OK', '2021-02-08 11:00:59', '2021-02-08 11:00:59', '{\"distance\":31457,\"distanceText\":\"31.5 km\",\"duration\":1630,\"durationText\":\"27 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(343, '03/05/2020', 'RUN: BRCITY19T', 69124476, 'MONROE, JACQUELINE', 'AM1', '4811 W 77TH ST', 'DIALYSIS CENTER /MK LOBBY DR CONT AT DOOR SHE W 77TH ST', NULL, 'CHICAGO', '773 440 8823', '-87.745912', '41.752664', 'AM1', '10200 S PEORIA ST', '1 WAY', NULL, 'CHICAGO', '773-238-3253', '-87.645329', '41.708700', '11:15:00', '11:15', NULL, NULL, NULL, NULL, NULL, 8.21, 3.25, NULL, 48.95, NULL, 'TAXI OK PLS CALL 1ST 773-440-8823', '2021-02-08 11:00:59', '2021-02-08 11:00:59', '{\"distance\":13295,\"distanceText\":\"13.3 km\",\"duration\":1486,\"durationText\":\"25 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(344, '03/05/2020', 'RUN: BRCITY19T', 69130940, 'JOHNSON, JARVIS', 'AM1', '206 W 110TH ST', 'RESI/ RING BELL', NULL, 'CHICAGO', '773-668-5857', '-87.628100', '41.694359', 'AM1', '10 W 35TH ST', NULL, NULL, 'CHICAGO', NULL, '-87.626947', '41.831016', '11:45:00', '11:45', '13:15', NULL, NULL, NULL, NULL, 9.51, 3.25, NULL, 53.4, NULL, 'TAXI OK', '2021-02-08 11:01:00', '2021-02-08 11:01:00', '{\"distance\":16326,\"distanceText\":\"16.3 km\",\"duration\":941,\"durationText\":\"16 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(345, '03/05/2020', 'RUN: BRCITY19T', 69124830, 'EASTER, EDNA', 'AM1', '2940 W 87TH ST', 'LBYCNT', NULL, 'CHICAGO', NULL, '-87.695827', '41.735353', 'AM1', '8016 S EVANS AVE', 'RINGBELL', '#2', 'CHICAGO', '773-994-2220', '-87.606412', '41.749134', '12:33:00', '12:33', NULL, NULL, NULL, NULL, NULL, 5.56, 3.25, NULL, 35.6, NULL, 'TAXI OK', '2021-02-08 11:01:00', '2021-02-08 11:01:00', '{\"distance\":8799,\"distanceText\":\"8.8 km\",\"duration\":1194,\"durationText\":\"20 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(346, '03/05/2020', 'RUN: BRCITY19T', 69132464, 'SIMMONS BAKER, SHIRLEY', 'AM2', '675 N SAINT CLAIR ST', 'MK LOBBY CONT', NULL, 'CHICAGO', '773-699-4605C', '-87.622731', '41.894347', 'AM2', '11835 S WENTWORTH AVE', NULL, NULL, 'CHICAGO', '773-821-5415H', '-87.627523', '41.679164', '13:30:00', '13:30', NULL, NULL, NULL, NULL, NULL, 15.13, 3.25, NULL, 76.76, NULL, 'TAXI OK', '2021-02-08 11:01:01', '2021-02-08 11:01:01', '{\"distance\":27306,\"distanceText\":\"27.3 km\",\"duration\":1688,\"durationText\":\"28 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(347, '03/05/2020', 'RUN: BRCITY19T', 69130958, 'JOHNSON, JARVIS', 'AM1', '10 W 35TH ST', 'LOBBY CNT', NULL, 'CHICAGO', '773-668-5857', '-87.626947', '41.831016', 'AM1', '206 W 110TH ST', 'RESI/ RING BELL', NULL, 'CHICAGO', '773-668-5857', '-87.628100', '41.694359', '15:07:00', '15:07', NULL, NULL, NULL, NULL, NULL, 9.51, 3.25, NULL, 53.4, NULL, 'TAXI OK', '2021-02-08 11:01:01', '2021-02-08 11:01:01', '{\"distance\":16260,\"distanceText\":\"16.3 km\",\"duration\":1049,\"durationText\":\"17 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(348, '03/05/2020', 'RUN: BRCITY19T', 69132554, 'JOHNSON, CHARLOTTE', 'AM1', '1634 W POLK ST', 'LBBY CNT', NULL, 'CHICAGO', NULL, '-87.667823', '41.871628', 'AM1', '11537 S HALE AVE', NULL, NULL, 'CHICAGO', '773-982-0103', '-87.672496', '41.683482', '15:30:00', '15:30', NULL, NULL, NULL, NULL, NULL, 13.26, 3.25, NULL, 68.98, NULL, 'TAXI OK', '2021-02-08 11:01:02', '2021-02-08 11:01:02', '{\"distance\":27083,\"distanceText\":\"27.1 km\",\"duration\":1395,\"durationText\":\"23 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(349, '03/05/2020', 'RUN: BRCITY20BT', 69131927, 'WEST, BARBARA', 'AM1', '2804 E 76TH ST', 'RING 2ND BELL FROM BOTTOM', '#2W', 'CHICAGO', '312-721-9174', '-87.556648', '41.758153', 'AM1', '9115 S CICERO AVE', 'DIALYSIS/MK LBBYC NT INSIDE', NULL, 'OAK LAWN', '312-721-9174', '-87.740966', '41.726635', '8:24:00', '8:24', '10:00', NULL, NULL, NULL, NULL, 11.68, 3.25, NULL, 61.19, NULL, 'TAXI OK', '2021-02-08 11:01:02', '2021-02-08 11:01:02', '{\"distance\":18492,\"distanceText\":\"18.5 km\",\"duration\":2055,\"durationText\":\"34 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(350, '03/05/2020', 'RUN: BRCITY20BT', 69132656, 'PERKINS, ROLANDA', 'AM1', '8833 S LUELLA AVE', NULL, NULL, 'CHICAGO', '404-993-1075', '-87.569613', '41.734728', 'AM1', '6234 W 95TH ST', NULL, NULL, 'OAK LAWN', NULL, '-87.776352', '41.719648', '8:59:00', '8:59', '10:30', NULL, NULL, NULL, NULL, 11.7, 3.25, NULL, 61.19, NULL, 'TAXI OK', '2021-02-08 11:01:03', '2021-02-08 11:01:03', '{\"distance\":20352,\"distanceText\":\"20.4 km\",\"duration\":1950,\"durationText\":\"33 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(351, '03/05/2020', 'RUN: BRCITY20BT', 69126886, 'SMITH, MICHAEL', 'AM1', '9831 S WESTERN AVE', 'LBBY', NULL, 'CHICAGO', NULL, '-87.681837', '41.714996', 'AM1', '1025 E 90TH ST', 'RING BELL', NULL, 'CHICAGO', '773-768-6445', '-87.598894', '41.731259', '9:45:00', '9:45', NULL, NULL, NULL, NULL, NULL, 5.4, 3.25, NULL, 35.6, NULL, 'TAXI OK', '2021-02-08 11:01:03', '2021-02-08 11:01:03', '{\"distance\":10124,\"distanceText\":\"10.1 km\",\"duration\":1028,\"durationText\":\"17 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(352, '03/05/2020', 'RUN: BRCITY20BT', 69132112, 'GILL, MARGARET', 'AM1', '8351 S LANGLEY AVE', NULL, '#1S', 'CHICAGO', '773-723-6899', '-87.607406', '41.741926', 'AM1', '2 N STATE ST', 'WALGREENS', NULL, 'CHICAGO', NULL, '-87.627812', '41.882066', '10:13:00', '10:13', NULL, NULL, NULL, NULL, NULL, 10.83, 3.25, NULL, 57.85, NULL, 'TAXI O K', '2021-02-08 11:01:04', '2021-02-08 11:01:04', '{\"distance\":19544,\"distanceText\":\"19.5 km\",\"duration\":1288,\"durationText\":\"21 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(353, '03/05/2020', 'RUN: BRCITY20BT', 69132086, 'PURNELL, ROSALIND', 'AM1', '9154 S COTTAGE GROVE AVE', 'CALL 773-554-9148', '#1B', 'CHICAGO', '773-554-9148', '-87.604728', '41.728126', 'AM1', '1401 S CALIFORNIA AVE', 'MK LBBY CNT INSIDE', NULL, 'CHICAGO', '773-554-9148', '-87.694530', '41.862783', '10:20:00', '10:20', '12:00', NULL, NULL, NULL, NULL, 13.99, 3.25, NULL, 71.2, NULL, 'TAXI OK', '2021-02-08 11:01:04', '2021-02-08 11:01:04', '{\"distance\":26056,\"distanceText\":\"26.1 km\",\"duration\":1511,\"durationText\":\"25 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(354, '03/05/2020', 'RUN: BRCITY20BT', 69131611, 'HALL, DOWAN', 'AM1', '1434 S SPAULDING AVE', NULL, NULL, 'CHICAGO', '773-230-3401', '-87.707964', '41.861903', 'AM1', '121 N LA SALLE ST', NULL, NULL, 'CHICAGO', '773-230-3401', '-87.632436', '41.883852', '11:17:00', '11:17', NULL, NULL, NULL, NULL, NULL, 5.4, 3.25, NULL, 35.6, NULL, 'TAXI OK', '2021-02-08 11:01:04', '2021-02-08 11:01:04', '{\"distance\":9269,\"distanceText\":\"9.3 km\",\"duration\":805,\"durationText\":\"13 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}'),
(355, '03/05/2020', 'RUN: BRCITY22T', 69130403, 'PATINO, DIANA', 'AM2', '4415 W BELMONT AVE', NULL, '#2', 'CHICAGO', '773-930-4991', '-87.737652', '41.938967', 'AM2', '1116 N KEDZIE AVE', NULL, NULL, 'CHICAGO', NULL, '-87.706239', '41.884575', '8:06:00', '8:06', NULL, NULL, NULL, NULL, NULL, 5.4, 3.25, NULL, 35.6, NULL, NULL, '2021-02-08 11:01:05', '2021-02-08 11:01:05', '{\"distance\":7594,\"distanceText\":\"7.6 km\",\"duration\":1155,\"durationText\":\"19 mins\",\"durationInTraffic\":null,\"durationInTrafficText\":null}');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255)  NOT NULL,
  `remember_token` varchar(100)  DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`) USING HASH
);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
