



    <footer class="clearfix">
        <div class="pull-right">
            Created with <i class="fa fa-heart text-danger"></i> by <a href="https://1.envato.market/ydb" target="_blank">Cursorocity </a>
        </div>
        <div class="pull-left">
            <span id="year-copy"></span> &copy; <a href="https://1.envato.market/qbN" target="_blank">Tickyplex</a>
        </div>
    </footer>





<!-- Start Main project js, jQuery, Bootstrap -->
<script src="/admin-assets/assets/bundles/lib.vendor.bundle.js"></script>

<!-- Start all plugin js -->
{{-- <script src="/admin-assets/assets/bundles/counterup.bundle.js"></script>
<script src="/admin-assets/assets/bundles/apexcharts.bundle.js"></script>
<script src="/admin-assets/assets/bundles/summernote.bundle.js"></script> --}}
@stack('scripts.plugin.src')
<!-- Start project main js  and page js -->
<script src="/admin-assets/assets/js/core.js"></script>
@stack('scripts.pages.src')
{{-- <script src="/admin-assets/assets/pages/js/page/index.js"></script>
<script src="/admin-assets/assets/pages/js/page/summernote.js"></script> --}}
