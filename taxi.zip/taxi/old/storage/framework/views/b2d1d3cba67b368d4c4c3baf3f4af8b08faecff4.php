



    <footer class="clearfix">
        <div class="pull-right">
            Crafted with <i class="fa fa-heart text-danger"></i> by <a href="https://1.envato.market/ydb" target="_blank">pixelcave</a>
        </div>
        <div class="pull-left">
            <span id="year-copy"></span> &copy; <a href="https://1.envato.market/qbN" target="_blank">FreshUI 2.1</a>
        </div>
    </footer>





<!-- Start Main project js, jQuery, Bootstrap -->
<script src="/admin-assets/assets/bundles/lib.vendor.bundle.js"></script>

<!-- Start all plugin js -->

<?php echo $__env->yieldPushContent('scripts.plugin.src'); ?>
<!-- Start project main js  and page js -->
<script src="/admin-assets/assets/js/core.js"></script>
<?php echo $__env->yieldPushContent('scripts.pages.src'); ?>

<?php /**PATH D:\wamp64\www\cab\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>