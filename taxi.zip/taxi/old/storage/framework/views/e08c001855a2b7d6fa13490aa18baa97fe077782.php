<form>

 
      
    <!--    <label class="control-label col-md-2" for="example-datepicker3">Datepicker (auto close on select)</label> -->
        <div class="col-md-2">
            <input type="text" id="date_of_service" name="date_of_service" class="form-control input-datepicker-close text-center" data-date-format="dd/mm/yy" placeholder="Select Date" autocomplete="off">
        </div>
        <div class="col-md-2">
            <select id="client_name" name="client_name" class="select-chosen" data-placeholder="Choose a Country..." style="width: 250px;">
            <option value="">Choose a Client...</option>
              <?php $__currentLoopData = $taxi_Manifests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                
                <option value="<?php echo e($item->Client_Name); ?>"> <?php echo e($item->Client_Name); ?> </option>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select>
        </div>
        <div class="col-sm-2">
        
            <input type="text" value="<?php echo e(request()->search); ?>" class="form-control" name="search" placeholder="Enter Booking Id">
        </div>
        
        <div class="col-md-1">
        <input type="submit" value="Genterate" class="btn btn-primary"/>
        </div>

    

</form> 


<table>

    <thead>
        <tr>
            <th class="text-center">#</th>
            <th>Start_Time</th>
            <th>Est_End_Time</th>
            <th>Trip_Duration </th>
            <th>Trip_Miles</th>
            <th>Date_Of_Service</th>
            <th>Run_Number</th>
            <th>Booking_ID</th>
            <th>Client_Name</th>
            <th>Space_On</th>
            <th>Origin_Street</th>
            <th>Origin_Comment</th>
            <th>Orig_Apt</th>
            <th>Origin_City</th>
            <th>Origin_Phone</th>
            <th>Origin_Lon</th>
            <th>Origin_Lat</th>
            <th>Space_Off</th>
            <th>Dest_Street</th>
            <th>Dest_Comment</th>
            <th>Dest_Apt</th>
            <th>Dest_City</th>
            <th>Dest_Phone</th>
            <th>Dest_Lon</th>
            <th>Dest_Lat</th>
            <th>Schedule_Time</th>
            <th>Neg_Time</th>
            <th>Appt_Time</th>
            <th>Origin_Actual_Arrive</th>
            <th>Origin_Actual_Depart</th>
            <th>Dest_Actual_Arrive</th>
            <th>Dest_Actual_Depart</th>
            <th>Trip_Distance</th>
            <th>Fare</th>
            <th>Fare_Collected</th>
            <th>Provider_Cost</th>
            <th>Adjusted_Cost</th>
            <th>Comments</th>
           
           
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $taxi_Manifests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <tr>
                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                <?php if($item->distance_data): ?>
                <td>
                   <?php echo e($item->schedule_time->format('h:i A')); ?>

                </td>
                <td>
                    <?php echo e(($item->est_end_time)?$item->est_end_time->format('h:i A'):''); ?> 
                </td>
                <td>
                    <?php if(isset($item->distance_data->durationText)): ?>
                        <?php echo e($item->distance_data->durationText); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <?php if(isset($item->distance_data->distance)): ?>
                        <?php echo e((int)$item->distance_data->distance * 0.000621); ?>

                    <?php endif; ?>
                </td>
                <?php endif; ?>
                <td><?php echo e($item->Date_Of_Service); ?></td>
                <td><?php echo e($item->Run_Number); ?></td>
                <td><?php echo e($item->Booking_ID); ?></td>
                <td><?php echo e($item->Client_Name); ?></td>
                <td><?php echo e($item->Space_On); ?></td>
                <td><?php echo e($item->Origin_Street); ?></td>
                <td><?php echo e($item->Origin_Comment); ?></td>
                <td><?php echo e($item->Orig_Apt); ?></td>
                <td><?php echo e($item->Origin_City); ?></td>
                <td><?php echo e($item->Origin_Phone); ?></td>
                <td><?php echo e($item->Origin_Lon); ?></td>
                <td><?php echo e($item->Origin_Lat); ?></td>
                <td><?php echo e($item->Space_Off); ?></td>
                <td><?php echo e($item->Dest_Street); ?></td>
                <td><?php echo e($item->Dest_Comment); ?></td>
                <td><?php echo e($item->Dest_Apt); ?></td>
                <td><?php echo e($item->Dest_City); ?></td>
                <td><?php echo e($item->Dest_Phone); ?></td>
                <td><?php echo e($item->Dest_Lon); ?></td>
                <td><?php echo e($item->Dest_Lat); ?></td>
                <td><?php echo e($item->schedule_time->format('H:i A')); ?></td>
                <td><?php echo e($item->Neg_Time); ?></td>
                <td><?php echo e($item->Appt_Time); ?></td>
                <td><?php echo e($item->Origin_Actual_Arrive); ?></td>
                <td><?php echo e($item->Origin_Actual_Depart); ?></td>
                <td><?php echo e($item->Dest_Actual_Arrive); ?></td>
                <td><?php echo e($item->Dest_Actual_Depart); ?></td>
                <td><?php echo e($item->Trip_Distance); ?></td>
                <td><?php echo e($item->Fare); ?></td>
                <td><?php echo e($item->Fare_Collected); ?></td>
                <td><?php echo e($item->Provider_Cost); ?></td>
                <td><?php echo e($item->Adjusted_Cost); ?></td>
                <td><?php echo e($item->Comments); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\wamp64\www\cab\resources\views/admin/partials/export.blade.php ENDPATH**/ ?>