<?php

use App\Http\Controllers\Taxi_ManifestController;
use Illuminate\Support\Facades\Route;
use App\Taxi_Manifest;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|


Route::get('/', function () {
    return view('admin.index');
});

*/

Route::get('/','Taxi_ManifestController@index')->name('pace_rides');
Route::get('/pace_rides','Taxi_ManifestController@index')->name('pace_rides');

Route::post('/import', 'Taxi_ManifestController@import')->name('taxi_manifest_import');


Route::get('/export', 'Taxi_ManifestController@export')->name('taxi_manifest_export');
