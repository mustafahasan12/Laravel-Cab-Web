<?php

function time_to_decimal($time) {
    $timeArr = explode(':', $time);
    $decTime = ($timeArr[0]*3600) + ($timeArr[1]) + ($timeArr[2]/3600);
 
    return $decTime;
}


?>