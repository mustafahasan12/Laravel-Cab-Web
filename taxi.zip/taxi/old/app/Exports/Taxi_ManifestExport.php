<?php

namespace App\Exports;

use App\Taxi_Manifest;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Illuminate\Support\Facades\View as BaseView;

class Taxi_ManifestExport implements FromView
{
    /**
    * @return \Illuminate\Support\Collection
    */
    // public function collection()
    // {

    //     return Taxi_Manifest::all();
    // }

    public function view(): View
    {

        if (BaseView::exists('admin.partials.export')) {
            return view('admin.partials.export', [
                'taxi_Manifests' => Taxi_Manifest::all()
            ]);
        }
    }
}
