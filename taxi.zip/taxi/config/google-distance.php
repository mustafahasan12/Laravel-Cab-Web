<?php

/**
 * Set your google api key.
 */
return [
    'api_key' => env('AIzaSyD79aW6rB132yhuZRDBHS96Q5TJOstjCzo'),
];
