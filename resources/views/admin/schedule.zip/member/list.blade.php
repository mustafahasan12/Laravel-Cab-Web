@extends('admin.layout.app')

@section('content')
<form action="{{route('member.store')}}"  method="POST" enctype="multipart/form-data" id="member_create">
    @csrf
    <div id="page-container">
       <div id="fx-container" class="fx-opacity">
          <div id="page-content" class="block">
             <div class="row gutter30">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table id="general-table" class="table table-bordered table-condensed table-hover">
                            <thead>
                                <tr>
                                    <th class="text-center"><input type="checkbox"></th>
                                    <th class="text-center">#</th>
                                    <th>Client</th>
                                    <th>Email</th>
                                    <th>Subscription</th>
                                    <th>Expires</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($members as $item)
                                <tr>
                                    <td class="text-center"><input type="checkbox" id="checkbox1-1" name="checkbox1-1"></td>
                                    <td class="text-center">{{$loop->iteration}}</td>
                                    <td><a href="javascript:void(0)">{{$item->first_name}}</a></td>
                                    <td>client1@company.com</td>
                                    <td><a href="javascript:void(0)" class="label label-success">VIP</a></td>
                                    <td><a href="javascript:void(0)" class="label label-success">Lifetime</a></td>
                                    <td class="text-center">
                                        <div class="btn-group btn-group-xs">
                                            <a href="{{route('member.edit',['id'=>$item->id])}}" data-toggle="tooltip" title="" class="btn btn-default" data-original-title="Edit"><i class="fa fa-pencil"></i></a>
                                            <a href="{{route('member.delete',['id'=>$item->id])}}" data-toggle="tooltip" title="" class="btn btn-default" data-original-title="Delete"><i class="fa fa-times"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="7">
                                        <div class="btn-group btn-group-sm pull-right">
                                            <a href="javascript:void(0)" class="btn btn-default" data-toggle="tooltip" title="" data-original-title="Settings"><i class="fa fa-cog"></i></a>
                                            <div class="btn-group btn-group-sm dropup">
                                                <a href="javascript:void(0)" class="btn btn-default pull-right dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></a>
                                                <ul class="dropdown-menu dropdown-menu-right">
                                                    <li><a href="javascript:void(0)"><i class="fa fa-print"></i> Print</a></li>
                                                    <li class="divider"></li>
                                                    <li class="dropdown-header"><i class="fa fa-share"></i> Export As</li>
                                                    <li><a href="javascript:void(0)">.pdf</a></li>
                                                    <li><a href="javascript:void(0)">.cvs</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="btn-group btn-group-sm">
                                            <a href="javascript:void(0)" class="btn btn-default" data-toggle="tooltip" title="" data-original-title="Edit Selected"><i class="fa fa-pencil"></i></a>
                                            <a href="javascript:void(0)" class="btn btn-default" data-toggle="tooltip" title="" data-original-title="Delete Selected"><i class="fa fa-times"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
             </div>
          </div>
       </div>
    </div>
 </form>
@endsection


@push('scripts')


<script>
    $(document).ready(function(){

        jQuery('[name="typeee"]').change(function(){
            if(jQuery(this).val() == 'Corporation'){
                $('#hidee').hide();
                $('#mycorporation').show();
            }

            if(jQuery(this).val() == 'Sole Propertier'){
                $('#hidee').show();
                $('#mycorporation').hide();
            }
        });



        $(document).ready(function(){
            $('#md').on('change',function(){
                var id=$(this).val();
                    var respone = (jQuery('#md option:selected').attr('data-json'))
                    var Data=JSON.parse(respone);

                    document.getElementById('veh_model').value=Data["Vehicle_Model"];
                    document.getElementById('veh_maker').value=Data["Vehicle_Maker"];
                    document.getElementById('exp_date').value=Data["Medallion_Expiry_Date"];

            });
        });

        $('#member_create_btn').click(function(e) {
            e.preventDefault();
            jQuery('#notice').hide()
            jQuery('.form-group').removeClass('has-error')
            jQuery('.help-block').remove()

            var formData = new FormData($('#member_create')[0]);
            $.ajax({
                url: '{{ route("member.store") }}',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(result)
                {
                    window.location = '{{route("ajax.redirect")}}?class='+result.class+'&message='+result.message+'&redirect='+result.redirect
                },
                error: function(data)
                {
                    jQuery('#notice').show()
                    jQuery('#notice .alert').html(data.responseJSON.message)

                    jQuery.each(data.responseJSON.errors,function(k,v){

                        jQuery('[name="'+k+'"]').closest('.form-group').addClass('has-error')
                        jQuery('[name="'+k+'"]').after('<div for="'+k+'" class="help-block">'+v[0]+'</div>')

                    })

                }
            });
        });
    });
    </script>

@endpush
